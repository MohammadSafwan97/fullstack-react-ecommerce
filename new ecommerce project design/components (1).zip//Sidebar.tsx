import { LayoutDashboard, Package, ShoppingCart, Users, BarChart3, Settings, LogOut } from 'lucide-react';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', active: false, count: null },
  { icon: Package, label: 'Products', active: true, count: null },
  { icon: ShoppingCart, label: 'Orders', active: false, count: 12 },
  { icon: Users, label: 'Customers', active: false, count: null },
  { icon: BarChart3, label: 'Analytics', active: false, count: null },
];

const systemItems = [
  { icon: Settings, label: 'Settings', active: false },
  { icon: LogOut, label: 'Logout', active: false },
];

export function Sidebar() {
  return (
    <aside className="fixed left-0 top-16 w-20 h-[calc(100vh-4rem)] bg-white border-r border-slate-200 flex flex-col items-center py-6">
      <nav className="space-y-2 flex-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="relative group">
              <button
                className={`
                  relative w-12 h-12 flex items-center justify-center rounded-xl transition-all
                  ${item.active 
                    ? 'bg-indigo-50 text-indigo-600' 
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }
                `}
              >
                <Icon className="w-5 h-5" />
                {item.count && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full flex items-center justify-center text-xs">
                    {item.count}
                  </span>
                )}
              </button>
              
              {/* Tooltip */}
              <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2 py-1 bg-slate-900 text-white rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                {item.label}
              </div>
            </div>
          );
        })}
      </nav>
      
      {/* System Section */}
      <div className="space-y-2">
        <div className="text-slate-400 text-xs px-3 mb-2">SYSTEM</div>
        {systemItems.map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="relative group">
              <button
                className="w-12 h-12 flex items-center justify-center rounded-xl text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-all"
              >
                <Icon className="w-5 h-5" />
              </button>
              
              {/* Tooltip */}
              <div className="absolute left-full ml-2 top-1/2 -translate-y-1/2 px-2 py-1 bg-slate-900 text-white rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                {item.label}
              </div>
            </div>
          );
        })}
      </div>
    </aside>
  );
}