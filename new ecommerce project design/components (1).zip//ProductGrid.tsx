import { ImageWithFallback } from './figma/ImageWithFallback';
import { Tag, Edit, Trash2 } from 'lucide-react';

const products = [
  {
    id: 1,
    name: 'Sonic Wireless Pro',
    price: 299,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3aXJlbGVzcyUyMGhlYWRwaG9uZXN8ZW58MXx8fHwxNzY0NTAzNzA4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'High-fidelity audio with active noise cancellation and 30h battery life.',
    status: 'In Stock',
    statusColor: 'emerald',
    category: 'Electronics',
  },
  {
    id: 2,
    name: 'ErgoChair Advance',
    price: 549,
    image: 'https://images.unsplash.com/photo-1688578735427-994ecdea3ea4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvZmZpY2UlMjBjaGFpcnxlbnwxfHx8fDE3NjQ1Nzk0MzJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Designed for comfort and productivity with lumbar support.',
    status: 'Low Stock',
    statusColor: 'amber',
    category: 'Furniture',
  },
  {
    id: 3,
    name: 'Chronos Smartwatch',
    price: 199,
    image: 'https://images.unsplash.com/photo-1579586337278-3befd40fd17a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzbWFydCUyMHdhdGNofGVufDF8fHx8MTc2NDU3ODkxN3ww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Stay connected with health tracking and seamless notifications.',
    status: 'In Stock',
    statusColor: 'emerald',
    category: 'Wearables',
  },
  {
    id: 4,
    name: 'Artisan Mug Set',
    price: 85,
    image: 'https://images.unsplash.com/photo-1666713711218-8ea7743c8ed1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjZXJhbWljJTIwbXVnJTIwc2V0fGVufDF8fHx8MTc2NDYwMjMzNHww&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Four set ceramics mugs perfect for coffee or tea.',
    status: 'Out of Stock',
    statusColor: 'slate',
    category: 'Home',
  },
  {
    id: 5,
    name: 'Velocity Runner X',
    price: 145,
    image: 'https://images.unsplash.com/photo-1597892657493-6847b9640bac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydW5uaW5nJTIwc2hvZXN8ZW58MXx8fHwxNzY0NTUwMDYwfDA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Lightweight running shoes designed for speed and comfort.',
    status: 'In Stock',
    statusColor: 'emerald',
    category: 'Sports',
  },
  {
    id: 6,
    name: 'Modern Laptop',
    price: 1299,
    image: 'https://images.unsplash.com/photo-1511385348-a52b4a160dc2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXB0b3AlMjBjb21wdXRlcnxlbnwxfHx8fDE3NjQ1NTQ1MTR8MA&ixlib=rb-4.1.0&q=80&w=1080',
    description: 'Powerful performance in a sleek, portable design.',
    status: 'In Stock',
    statusColor: 'emerald',
    category: 'Electronics',
  },
];

const statusStyles = {
  emerald: 'bg-emerald-100 text-emerald-700',
  amber: 'bg-amber-100 text-amber-700',
  slate: 'bg-slate-100 text-slate-700',
};

export function ProductGrid() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {products.map((product) => (
        <div
          key={product.id}
          className="bg-white rounded-xl overflow-hidden border border-slate-200 hover:shadow-lg transition-shadow"
        >
          {/* Product Image */}
          <div className="relative aspect-[4/3] overflow-hidden bg-slate-100">
            <ImageWithFallback
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
            
            {/* Status Badge */}
            <div className="absolute top-3 left-3">
              <span className={`px-3 py-1 rounded-md text-xs ${statusStyles[product.statusColor as keyof typeof statusStyles]}`}>
                {product.status}
              </span>
            </div>
          </div>
          
          {/* Product Info */}
          <div className="p-5">
            <div className="flex items-start justify-between mb-2">
              <h3 className="text-slate-900 flex-1">{product.name}</h3>
              <span className="text-slate-900 ml-3">${product.price}</span>
            </div>
            
            <p className="text-slate-500 mb-4 line-clamp-2">{product.description}</p>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-slate-500">
                <Tag className="w-4 h-4" />
                <span>{product.category}</span>
              </div>
              
              <div className="flex items-center gap-1">
                <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-600 hover:text-indigo-600">
                  <Edit className="w-4 h-4" />
                </button>
                <button className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-600 hover:text-red-600">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}